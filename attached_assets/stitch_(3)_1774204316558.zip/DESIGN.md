```markdown
# Design System Specification: Editorial Fluidity

## 1. Overview & Creative North Star: "The Diffusion Gallery"
This design system is an exercise in high-end restraint. Our Creative North Star is **The Diffusion Gallery**—an aesthetic where the interface acts as a pristine, glass-like lens over a living, organic background. 

Moving away from the rigid, boxed-in layouts of standard web design, this system prioritizes **intentional asymmetry** and **atmospheric depth**. The "Diffusion" comes from the background: a liquid emerald and moss green flow (`#2D4C3E`) that mimics ink dispersing in water. The UI sits above this movement, utilizing extreme whitespace and sophisticated monochromatic typography to create a sense of calm authority. We do not build "pages"; we curate "compositions."

---

## 2. Colors: The Monochromatic Lens
The palette is strictly divided between the organic background and the clinical, high-contrast interface.

### The Background Strategy
The base is `surface` (`#f9faf8`). The "ink" uses `tertiary` (`#224134`) and `tertiary_fixed_dim` (`#2e4d3f`). These greens should never be used for text or structural UI; they are purely atmospheric, living in the background layer.

### The "No-Line" Rule
**Borders are prohibited for sectioning.** To define a new area, use a background shift.
*   Place a `surface_container_low` (`#f3f4f2`) section directly onto the `surface` (`#f9faf8`) background.
*   The transition provides enough contrast for the eye without the "cheapening" effect of a 1px line.

### Surface Hierarchy & Nesting
Treat the UI as a stack of physical, semi-transparent layers:
1.  **Level 0 (Base):** `surface` with fluid emerald movement.
2.  **Level 1 (Sections):** `surface_container` (`#edeeec`) for large content blocks.
3.  **Level 2 (Interaction):** `surface_container_highest` (`#e2e3e1`) for active elements or elevated cards.

### The Glass & Gradient Rule
Floating elements (modals, navigation bars) must use **Glassmorphism**. 
*   **Fill:** `surface_container_lowest` (`#ffffff`) at 70-85% opacity.
*   **Effect:** `backdrop-filter: blur(20px)`.
*   **Result:** This allows the emerald background to "bleed" through the UI, integrating the content with the atmosphere.

---

## 3. Typography: Editorial Authority
We utilize two typefaces to balance character with functional clarity.

*   **Display & Headlines (Manrope):** Use `display-lg` (3.5rem) and `headline-lg` (2rem) with tight letter-spacing (-0.02em) to create a bold, editorial look. Headlines should feel like a magazine masthead—authoritative and anchored.
*   **Body & Utility (Inter):** Use `label-md` (0.75rem) for metadata and micro-copy. Inter provides the technical "modern" counter-balance to the expressive Manrope headlines.
*   **Monochromatic Hierarchy:** All text must strictly use `on_surface` (`#191c1b`) for high readability or `on_surface_variant` (`#474747`) for secondary information. Never use the emerald green for text.

---

## 4. Elevation & Depth: Tonal Layering
Depth in this system is felt, not seen through heavy shadows.

*   **The Layering Principle:** Avoid "Drop Shadows" for standard cards. Instead, place a `surface_container_lowest` card on a `surface_container_low` background. The subtle shift from `#ffffff` to `#f3f4f2` creates a sophisticated "lift."
*   **Ambient Shadows:** If an element must float (e.g., a primary CTA menu), use an extra-diffused shadow:
    *   `box-shadow: 0 20px 40px rgba(25, 28, 27, 0.06);` (Using a 6% opacity of `on_surface`).
*   **The "Ghost Border" Fallback:** If a boundary is strictly required for accessibility, use `outline_variant` (`#c6c6c6`) at 20% opacity. It should be barely perceptible.

---

## 5. Components: Minimalist Primitives

### Buttons
*   **Primary:** `primary` (`#000000`) background with `on_primary` (`#e5e2e1`) text. 0.5rem (DEFAULT) corner radius. High contrast, no gradient.
*   **Secondary:** Glass-style. `surface_container_highest` at 40% opacity with a `backdrop-blur`.
*   **Tertiary:** Text-only using `title-sm` (Manrope, 1rem) with a 2px underline that appears on hover.

### Cards & Lists
*   **Rule:** Forbid divider lines.
*   **Implementation:** Separate list items with `spacing-4` (1.4rem). Use a subtle hover state change to `surface_container_low` to indicate interactivity.
*   **Asymmetry:** In a grid of cards, vary the vertical padding slightly between odd and even items to break the "template" feel.

### Input Fields
*   **Style:** Minimalist underline or soft-tinted box.
*   **Focus:** Transition the background from `surface_container` to `surface_container_highest`. Do not use a bright blue focus ring; use a 1.5px `primary` black underline.

### Navigation (The Floating Dock)
*   A fixed bottom-center or top-center dock.
*   Style: `surface_container_lowest` (white) @ 80% opacity, `xl` (1.5rem) radius, backdrop-blur 24px.

---

## 6. Do’s and Don’ts

### Do:
*   **Do** use extreme whitespace (`spacing-16` and `spacing-20`) to frame important content.
*   **Do** allow the green liquid background to be the only "color" in the experience.
*   **Do** use `full` (9999px) roundedness for chips and tags to contrast with the `0.5rem` radius of cards.
*   **Do** treat images as gallery pieces—use generous padding and subtle `surface_dim` backgrounds behind them.

### Don't:
*   **Don't** use 100% opaque borders to separate content.
*   **Don't** use the green (`#2D4C3E`) for icons or buttons; it is for the "atmosphere" only.
*   **Don't** use standard "Material Design" shadows. Keep them large, soft, and nearly invisible.
*   **Don't** crowd the layout. If it feels "full," remove an element or increase the spacing scale.

---

## 7. Spacing & Rhythm
This system relies on a non-linear spacing scale to create an editorial rhythm.
*   **Micro-spacing (1-3):** Use for internal component padding (e.g., button labels).
*   **Macro-spacing (8-24):** Use for section margins and layout offsets. 
*   **The "Golden Gap":** Use `spacing-12` (4rem) as the default vertical margin between distinct content sections to maintain the "Ethereal" breathability.```